package com.gp.app.cricket_fox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CricketFoxApplication {

	public static void main(String[] args) {
		SpringApplication.run(CricketFoxApplication.class, args);
	}

}
