package com.gp.app.cricket_fox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CricketFoxApplicationTests {

	@Test
	void contextLoads() {
	}

}
